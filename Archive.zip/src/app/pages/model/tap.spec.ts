import { Tap } from './tap';

describe('Tap', () => {
  it('should create an instance', () => {
    expect(new Tap()).toBeTruthy();
  });
});
