import {Component} from '@angular/core';
@Component({
  selector: 'app-step',
  templateUrl: './step.html'
})
// tslint:disable-next-line:component-class-suffix
export class Step {

}
