import { NavBasicComponent } from './nav-basic.component';

describe('NavBasic', () => {
  it('should create an instance', () => {
    expect(new NavBasicComponent()).toBeTruthy();
  });
});
