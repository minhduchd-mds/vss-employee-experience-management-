import {Component} from '@angular/core';

@Component({
  selector: 'app-nav-basic',
  templateUrl: './tab.html'
})
export class NavBasicComponent {
  active = 1;
}
