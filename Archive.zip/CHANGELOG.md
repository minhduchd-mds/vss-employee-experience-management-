## [1.3.0] - 2021-07-15
### Updates
- update to Angular 12
- update all dependencies to match Angular 12 version

When you build and serve your app it is possible that some warnings to appear on your terminal. Those will NOT affect your product.

## [1.2.0] - 2020-10-02
### Updates
- update to Angular 10
- update all dependencies to match Angular 10 version


## [1.1.0] - 2020-03-06
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version


## [1.0.1] - 2019-08-05
### Bug fixing
- fix datepicker style

## [1.0.0] - 2019-03-14
### Initial Release
